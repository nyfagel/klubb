--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: klubb; Type: COMMENT; Schema: -; Owner: klubb
--

COMMENT ON DATABASE klubb IS 'Database for the local installation of Klubb.';


--
-- Name: klubb; Type: SCHEMA; Schema: -; Owner: klubb
--

CREATE SCHEMA klubb;


ALTER SCHEMA klubb OWNER TO klubb;

--
-- Name: SCHEMA klubb; Type: COMMENT; Schema: -; Owner: klubb
--

COMMENT ON SCHEMA klubb IS 'Default schema for Klubb.';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = klubb, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: authentication; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE authentication (
    "user" integer NOT NULL,
    series character varying(255) NOT NULL,
    key character varying(255) NOT NULL,
    created integer NOT NULL
);


ALTER TABLE klubb.authentication OWNER TO klubb;

--
-- Name: ci_sessions; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE ci_sessions (
    session_id character varying(40) DEFAULT '0'::character varying NOT NULL,
    ip_address character varying(45) DEFAULT '0'::character varying NOT NULL,
    user_agent character varying(120) NOT NULL,
    last_activity integer DEFAULT 0 NOT NULL,
    user_data text NOT NULL
);


ALTER TABLE klubb.ci_sessions OWNER TO klubb;

--
-- Name: keys; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE keys (
    id integer NOT NULL,
    key character varying(40) NOT NULL,
    level smallint NOT NULL,
    ignore_limits boolean DEFAULT false NOT NULL,
    is_private_key boolean DEFAULT false NOT NULL,
    ip_addresses text,
    date_created integer NOT NULL
);


ALTER TABLE klubb.keys OWNER TO klubb;

--
-- Name: keys_id_seq; Type: SEQUENCE; Schema: klubb; Owner: klubb
--

CREATE SEQUENCE keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE klubb.keys_id_seq OWNER TO klubb;

--
-- Name: keys_id_seq; Type: SEQUENCE OWNED BY; Schema: klubb; Owner: klubb
--

ALTER SEQUENCE keys_id_seq OWNED BY keys.id;


--
-- Name: limits; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE limits (
    id integer NOT NULL,
    uri character varying(255) NOT NULL,
    count integer NOT NULL,
    hour_started integer NOT NULL,
    api_key character varying(40) NOT NULL
);


ALTER TABLE klubb.limits OWNER TO klubb;

--
-- Name: limits_id_seq; Type: SEQUENCE; Schema: klubb; Owner: klubb
--

CREATE SEQUENCE limits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE klubb.limits_id_seq OWNER TO klubb;

--
-- Name: limits_id_seq; Type: SEQUENCE OWNED BY; Schema: klubb; Owner: klubb
--

ALTER SEQUENCE limits_id_seq OWNED BY limits.id;


--
-- Name: log; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE log (
    id integer NOT NULL,
    "user" integer,
    action character varying(45) NOT NULL,
    path character varying(100),
    "time" timestamp with time zone NOT NULL
);


ALTER TABLE klubb.log OWNER TO klubb;

--
-- Name: log_id_seq; Type: SEQUENCE; Schema: klubb; Owner: klubb
--

CREATE SEQUENCE log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE klubb.log_id_seq OWNER TO klubb;

--
-- Name: log_id_seq; Type: SEQUENCE OWNED BY; Schema: klubb; Owner: klubb
--

ALTER SEQUENCE log_id_seq OWNED BY log.id;


--
-- Name: logs; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE logs (
    id integer NOT NULL,
    uri character varying(255) NOT NULL,
    method character varying(6) NOT NULL,
    params text,
    api_key character varying(40) NOT NULL,
    ip_address character varying(45) NOT NULL,
    "time" integer NOT NULL,
    authorized boolean NOT NULL
);


ALTER TABLE klubb.logs OWNER TO klubb;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: klubb; Owner: klubb
--

CREATE SEQUENCE logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE klubb.logs_id_seq OWNER TO klubb;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: klubb; Owner: klubb
--

ALTER SEQUENCE logs_id_seq OWNED BY logs.id;


--
-- Name: member_data; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE member_data (
    id integer NOT NULL,
    notes text,
    inactive boolean DEFAULT false,
    inactive_date date
);


ALTER TABLE klubb.member_data OWNER TO klubb;

--
-- Name: member_data_id_seq; Type: SEQUENCE; Schema: klubb; Owner: klubb
--

CREATE SEQUENCE member_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE klubb.member_data_id_seq OWNER TO klubb;

--
-- Name: member_data_id_seq; Type: SEQUENCE OWNED BY; Schema: klubb; Owner: klubb
--

ALTER SEQUENCE member_data_id_seq OWNED BY member_data.id;


--
-- Name: members; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE members (
    id integer NOT NULL,
    type integer,
    firstname character varying(45) NOT NULL,
    lastname character varying(45) NOT NULL,
    ssid character varying(12) NOT NULL,
    phone character varying(12) NOT NULL,
    address character varying(45),
    zip character varying(10),
    city character varying(45),
    data integer
);


ALTER TABLE klubb.members OWNER TO klubb;

--
-- Name: members_id_seq; Type: SEQUENCE; Schema: klubb; Owner: klubb
--

CREATE SEQUENCE members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE klubb.members_id_seq OWNER TO klubb;

--
-- Name: members_id_seq; Type: SEQUENCE OWNED BY; Schema: klubb; Owner: klubb
--

ALTER SEQUENCE members_id_seq OWNED BY members.id;


--
-- Name: migrations; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE migrations (
    version integer NOT NULL
);


ALTER TABLE klubb.migrations OWNER TO klubb;

--
-- Name: rights; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE rights (
    id integer NOT NULL,
    role integer NOT NULL,
    add_members boolean DEFAULT false NOT NULL,
    add_users boolean DEFAULT false NOT NULL,
    use_system boolean DEFAULT true NOT NULL
);


ALTER TABLE klubb.rights OWNER TO klubb;

--
-- Name: rights_id_seq; Type: SEQUENCE; Schema: klubb; Owner: klubb
--

CREATE SEQUENCE rights_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE klubb.rights_id_seq OWNER TO klubb;

--
-- Name: rights_id_seq; Type: SEQUENCE OWNED BY; Schema: klubb; Owner: klubb
--

ALTER SEQUENCE rights_id_seq OWNED BY rights.id;


--
-- Name: roles; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE roles (
    id integer NOT NULL,
    name character varying(45) NOT NULL,
    system boolean DEFAULT true NOT NULL
);


ALTER TABLE klubb.roles OWNER TO klubb;

--
-- Name: role_view; Type: VIEW; Schema: klubb; Owner: klubb
--

CREATE VIEW role_view AS
    SELECT roles.id, rights.add_members, rights.add_users, rights.use_system, roles.name, roles.system AS system_role FROM roles, rights WHERE (roles.id = rights.role);


ALTER TABLE klubb.role_view OWNER TO klubb;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: klubb; Owner: klubb
--

CREATE SEQUENCE roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE klubb.roles_id_seq OWNER TO klubb;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: klubb; Owner: klubb
--

ALTER SEQUENCE roles_id_seq OWNED BY roles.id;


--
-- Name: system; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE system (
    key character varying(45) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE klubb.system OWNER TO klubb;

--
-- Name: types; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE types (
    id integer NOT NULL,
    name character varying(45) NOT NULL,
    plural character varying(45),
    "desc" character varying(65)
);


ALTER TABLE klubb.types OWNER TO klubb;

--
-- Name: types_id_seq; Type: SEQUENCE; Schema: klubb; Owner: klubb
--

CREATE SEQUENCE types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE klubb.types_id_seq OWNER TO klubb;

--
-- Name: types_id_seq; Type: SEQUENCE OWNED BY; Schema: klubb; Owner: klubb
--

ALTER SEQUENCE types_id_seq OWNED BY types.id;


--
-- Name: user_role; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE user_role (
    "user" integer NOT NULL,
    role integer NOT NULL
);


ALTER TABLE klubb.user_role OWNER TO klubb;

--
-- Name: users; Type: TABLE; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    firstname character varying(100),
    lastname character varying(100),
    email character varying(255) NOT NULL,
    phone character varying(12),
    key character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    registered integer NOT NULL,
    first_login boolean DEFAULT true NOT NULL,
    loggedin boolean DEFAULT false NOT NULL
);


ALTER TABLE klubb.users OWNER TO klubb;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: klubb; Owner: klubb
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE klubb.users_id_seq OWNER TO klubb;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: klubb; Owner: klubb
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: id; Type: DEFAULT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY keys ALTER COLUMN id SET DEFAULT nextval('keys_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY limits ALTER COLUMN id SET DEFAULT nextval('limits_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY log ALTER COLUMN id SET DEFAULT nextval('log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY logs ALTER COLUMN id SET DEFAULT nextval('logs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY member_data ALTER COLUMN id SET DEFAULT nextval('member_data_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY members ALTER COLUMN id SET DEFAULT nextval('members_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY rights ALTER COLUMN id SET DEFAULT nextval('rights_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY roles ALTER COLUMN id SET DEFAULT nextval('roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY types ALTER COLUMN id SET DEFAULT nextval('types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: authentication; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY authentication ("user", series, key, created) FROM stdin;
1	fd6d31e54be43230d5791627818356e247aa0e4c492396af681fb741a52c5fbb	c201e5f14cdaa27809f5f2636445a06855cad92a132ac00562707ce1e64f280e	1360167208
1	4c712c00cd77ab35d7085509933cf1a40e8871c19edef7f71983f5065f82fa29	886e0a4dce378ddc4746b5721998f2a0224a0c3a56f9b173b868e94e3be04f45	1360167317
\.


--
-- Data for Name: ci_sessions; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY ci_sessions (session_id, ip_address, user_agent, last_activity, user_data) FROM stdin;
23774fc8472f716fe2f4e33cc0198617	10.190.51.113	ELB-HealthChecker/1.0	1360162348	
91a98ae7e66444e2a48f3297481d62f7	10.190.51.113	ELB-HealthChecker/1.0	1360162438	
2bea9d7c0e650f42276a2583aa1a021c	10.190.51.113	ELB-HealthChecker/1.0	1360162498	
b3320cf4dc69164ab7e170b0d1995b69	10.190.51.113	ELB-HealthChecker/1.0	1360162558	
d67952dda45d926f336fc8c00f7700bc	10.190.51.113	ELB-HealthChecker/1.0	1360162648	
87d73dc4b36b5c6b465134043d08311e	10.190.51.113	ELB-HealthChecker/1.0	1360162738	
5a2e6c706359b2b19ed14ae257297ec9	10.190.51.113	ELB-HealthChecker/1.0	1360162798	
ee1c6b22259bee4cd7c6abe5547fb663	10.190.51.113	ELB-HealthChecker/1.0	1360162858	
e522ef0d893c7ba189d3f8c35b79bfbb	10.190.51.113	ELB-HealthChecker/1.0	1360165648	
38a6fb7e6803676a63ce007f6de3ad64	10.190.51.113	ELB-HealthChecker/1.0	1360162948	
d2201beece61e7364b99ff8d339a9dc8	10.190.51.113	ELB-HealthChecker/1.0	1360163038	
1fe0f8211e90b6c2873ccd6f92280684	10.190.51.113	ELB-HealthChecker/1.0	1360163098	
e8008882b0c446ce590077999486fe55	10.190.51.113	ELB-HealthChecker/1.0	1360163158	
1dab4707a2edad47c55c95b5d2614f95	10.190.51.113	ELB-HealthChecker/1.0	1360163248	
2a9d4a490748858a25d408cde4c25cc7	10.190.51.113	ELB-HealthChecker/1.0	1360163338	
8a1675468aa7f10e7f1d78a057ffd47c	10.190.51.113	ELB-HealthChecker/1.0	1360163398	
592c03d96b2703fecb4331edf4742ff1	10.190.51.113	ELB-HealthChecker/1.0	1360163458	
d5e47f818e8d2506fb498d0b1375cfb2	10.190.51.113	ELB-HealthChecker/1.0	1360163548	
4ba9c1747f4f58d66019cd7e26eddf94	10.190.51.113	ELB-HealthChecker/1.0	1360164748	
ce71103b80f75d762b3105e84e63b2a0	10.190.51.113	ELB-HealthChecker/1.0	1360164839	
3ab7cf8a5ede1be992b3eec45a449441	10.190.51.113	ELB-HealthChecker/1.0	1360164898	
737fc2eed28f02ce93386f68a4ed81a9	10.190.51.113	ELB-HealthChecker/1.0	1360164958	
0342f665bd35595d02dc651f6b2c7421	10.190.51.113	ELB-HealthChecker/1.0	1360165048	
b0faa4fcab07c8fe73605e22770d265e	10.190.51.113	ELB-HealthChecker/1.0	1360165138	
c6b451ab6070a9d754581dfd8020fd7d	10.190.51.113	ELB-HealthChecker/1.0	1360165198	
dbce1ab6ee43063733852c3f7a3f86da	10.190.51.113	ELB-HealthChecker/1.0	1360165258	
46b707041eda54637c358da7d0d004a4	10.190.51.113	ELB-HealthChecker/1.0	1360165348	
c3fcecfaf8940decd863c0f3decc8707	10.190.51.113	ELB-HealthChecker/1.0	1360165438	
cf78e7228976bb3bd9b15fcaf2d9bf69	10.190.51.113	ELB-HealthChecker/1.0	1360165498	
cf657a64b5b9eb7e57f213996b0259e8	10.190.51.113	ELB-HealthChecker/1.0	1360165559	
630e350a0aa4dac73d742d4990e99d6b	10.190.51.113	ELB-HealthChecker/1.0	1360165738	
272b8d1f3b59c985b60fc19d3bbd89be	10.190.51.113	ELB-HealthChecker/1.0	1360165798	
7eb2523c9fe176c8f7803bb9dc60e8ed	10.190.51.113	ELB-HealthChecker/1.0	1360165858	
fc635ab1ec2eea93214e57173fd68584	10.190.51.113	ELB-HealthChecker/1.0	1360165948	
60724041f3ad0008b92b743d99f3731e	10.190.51.113	ELB-HealthChecker/1.0	1360166038	
50927578686f613f7b1aa83282b0e0af	10.190.51.113	ELB-HealthChecker/1.0	1360166098	
a8344026e78e8aa52edfca047acb14e3	10.190.51.113	ELB-HealthChecker/1.0	1360166158	
5a3bfd31f382a32789820cfc84dadb53	10.190.51.113	ELB-HealthChecker/1.0	1360166248	
5c51d39096b587bc8818cd9ccb94b8dd	10.190.51.113	ELB-HealthChecker/1.0	1360166338	
389f3ea6a29add34682e0e41f90bd965	10.190.51.113	ELB-HealthChecker/1.0	1360166398	
45dda6b7abcdde25b2e2b42decc2cfff	10.190.51.113	ELB-HealthChecker/1.0	1360166458	
61a445a1b3e715d2e3b6d94708124a64	10.190.51.113	ELB-HealthChecker/1.0	1360166548	
1fb57ae01389f476649abb4a25f63b07	10.190.51.113	ELB-HealthChecker/1.0	1360166638	
106390ad9d4bd13c9abb8fc48c1f009e	10.190.51.113	ELB-HealthChecker/1.0	1360162378	
bb80b3b0d264ff7b3a42bba34f872304	10.190.51.113	ELB-HealthChecker/1.0	1360162468	
4b10169de31183319dd34883aa1a73eb	10.190.51.113	ELB-HealthChecker/1.0	1360162528	
fe76178aecf8c4ed9668b4df9e713400	10.190.51.113	ELB-HealthChecker/1.0	1360162588	
84b1dbeeeb0d0e2587473bc0beca60e1	10.190.51.113	ELB-HealthChecker/1.0	1360162678	
6b00392b7e7a479c8338536484396d7a	10.190.51.113	ELB-HealthChecker/1.0	1360162768	
eae9b09aac9737431d0c4a9e917787fa	10.190.51.113	ELB-HealthChecker/1.0	1360162828	
64964df0ce871df22e3fd07d7c5c2e35	10.190.51.113	ELB-HealthChecker/1.0	1360162888	
9dce495c28f99ccef5455cf7603cef05	10.190.51.113	ELB-HealthChecker/1.0	1360162978	
03a1e139f4eab05a4de4401317d8c6f8	10.190.51.113	ELB-HealthChecker/1.0	1360163068	
cd9a1da7ac2bd089afc1e22369c47108	10.190.51.113	ELB-HealthChecker/1.0	1360163128	
d342c4ba01625771bc213871852b5c7e	10.190.51.113	ELB-HealthChecker/1.0	1360163188	
254627e0a39dca0996b7baeaa00c8645	10.190.51.113	ELB-HealthChecker/1.0	1360163278	
3aff9dff343b9ec3192862694f006770	10.190.51.113	ELB-HealthChecker/1.0	1360163368	
35309ba08f6c4690281843d39e14cf9b	10.190.51.113	ELB-HealthChecker/1.0	1360163428	
5832f9c1cef2c0258c1fce1071f325f5	10.190.51.113	ELB-HealthChecker/1.0	1360163489	
2ffe2dddbf1a8abdbbe1b0224a682c64	10.190.51.113	ELB-HealthChecker/1.0	1360163578	
42ea5324a9d935e37e5c65ecfbc29067	10.190.51.113	ELB-HealthChecker/1.0	1360165678	
c039654a9d4448a865fed8b927578f44	10.190.51.113	ELB-HealthChecker/1.0	1360165768	
5efebb95215b10fa19597db1079e1bbc	10.190.51.113	ELB-HealthChecker/1.0	1360165828	
520e0c0bbf9e43d87b23cfe2c779ea23	10.190.51.113	ELB-HealthChecker/1.0	1360165888	
f872613dfe40fa12483a16134497c347	10.190.51.113	ELB-HealthChecker/1.0	1360165978	
1eb12689e660d6d9f8c9ade7fc11e8af	10.190.51.113	ELB-HealthChecker/1.0	1360166068	
672e7241571533117d4ca21932c4831e	10.190.51.113	ELB-HealthChecker/1.0	1360166129	
4366130727ef6cb991131346804a387c	10.190.51.113	ELB-HealthChecker/1.0	1360166188	
d8976775a154f09bc8fb76fb9bed6021	10.190.51.113	ELB-HealthChecker/1.0	1360166278	
af00f07e399ad1edb46b9a38c7fa9c7b	10.190.51.113	ELB-HealthChecker/1.0	1360166368	
bf9de727b90075d7e7ab805293b42eaf	10.190.51.113	ELB-HealthChecker/1.0	1360166428	
2c4e813f81fa672c6734908e26452b46	10.190.51.113	ELB-HealthChecker/1.0	1360166488	
9ba77430a2fd80ea668d896d90574fd8	10.190.51.113	ELB-HealthChecker/1.0	1360166578	
b7888c0751ce0ce14fb39ea30ef3d9d7	10.190.51.113	ELB-HealthChecker/1.0	1360162408	
737f0fd4b4677222f93040e7ad7637c2	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360162472	
0c656a1190e6ce2654eb8a66126ae13b	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360162541	
0dc5e14010fb5c84740e9d1eccda8998	10.190.51.113	ELB-HealthChecker/1.0	1360162618	
0a4ad16ee9a9f2d599e57e351d0206ed	10.190.51.113	ELB-HealthChecker/1.0	1360162708	
385fada7ab7305460b980bd77f7dc563	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360162772	
bb862606b064d469470efe0d0525f9c6	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360162841	
3d08e655ea62fc6ceda46bf0c4be9fde	10.190.51.113	ELB-HealthChecker/1.0	1360162918	
00d5fc48d194f334d79ee179886afa93	10.190.51.113	ELB-HealthChecker/1.0	1360163008	
502698748fb15e91e15721e8b5338c5a	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360163072	
23774d934f0de9a0bf3c3343d6f24599	10.190.51.113	ELB-HealthChecker/1.0	1360165708	
0db7c4403e571ecc391194d55fe7b18b	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360165772	
75aaa390cf69867aec287fa2b7c4264c	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360165841	
98a6e8226c9b6cb6d4493bfe2b101778	10.190.51.113	ELB-HealthChecker/1.0	1360165918	
b092796b8c14e42231c597db661e6275	10.190.51.113	ELB-HealthChecker/1.0	1360166008	
3a372939b81c9cc86f68cbc4b85eaa88	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360166072	
1b1ae25c19cdf16fbdf0abd954815043	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360166141	
6ae78e12864b7549a389418db3eaa321	10.190.51.113	ELB-HealthChecker/1.0	1360166218	
34c05696e71341a9eea84328214730c4	10.190.51.113	ELB-HealthChecker/1.0	1360166308	
17d5b0d4f786ef4c75ec7a3954e9b142	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360166372	
f385534c8a9e8702e9a5d4435fd4eb80	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360166442	
4b549c30ff1101e90effef6953add24f	10.190.51.113	ELB-HealthChecker/1.0	1360166518	
56032810e3f5981531f8362b57c54beb	10.190.51.113	ELB-HealthChecker/1.0	1360166608	
73faf481b07be078d6e1232b7d80ac6d	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360163142	
49148217e45030800c270ab8bf836c3a	10.190.51.113	ELB-HealthChecker/1.0	1360163218	
c50037829b096ec7c5b3d412aba47756	10.190.51.113	ELB-HealthChecker/1.0	1360163308	
8e7e3943b923344d6066142a664671c8	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360163372	
50f13710ce1f05ee3edd220a418c89d7	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360163441	
9d21c29d39d89352505c357b73ead67a	10.190.51.113	ELB-HealthChecker/1.0	1360163521	
e7dedd836aa50dfae8d55debe9f3b725	10.190.51.113	ELB-HealthChecker/1.0	1360166668	
48972425dc622bd3fb50e99da8a3b251	10.190.51.113	ELB-HealthChecker/1.0	1360166728	
6734c70d0cfad83c61b2ee2ed1739a01	10.190.51.113	ELB-HealthChecker/1.0	1360166788	
e3333357128bcb721dfb0cc18fe1a147	10.190.51.113	ELB-HealthChecker/1.0	1360166878	
85281b26ea23000f021f47ac5b5df039	10.190.51.113	ELB-HealthChecker/1.0	1360166968	
ef108cd69f4ed0d48217b6326aa87ca1	10.190.51.113	ELB-HealthChecker/1.0	1360167028	
ea8227218d420754cf26658fc68a93de	10.190.51.113	ELB-HealthChecker/1.0	1360167088	
bbdf27e10e81d09d94c4b01927650619	10.190.51.113	ELB-HealthChecker/1.0	1360167178	
f2e26057f142a4373f31156b2845f030	10.190.51.113	ELB-HealthChecker/1.0	1360167238	
81a3e4d12c6fd079467f8b7b5b219311	10.190.51.113	ELB-HealthChecker/1.0	1360167299	
359a2bc1df8f2bc103146e3a933d113c	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360167341	
3b88ac3ed25f41067695a72436d632fb	10.190.51.113	ELB-HealthChecker/1.0	1360167419	
8aa1f1fed8593e762c914968b96e09a1	10.190.51.113	ELB-HealthChecker/1.0	1360167508	
c7f83cb8874852aaf5af8af684718a43	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360167573	
9f46ed70f4848a38e8f0a134097468c4	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360167642	
7c948b50468714a324eaa3c920b3dd1c	10.190.51.113	ELB-HealthChecker/1.0	1360167718	
251e043fc00281ea93ba76a1828acf4d	10.190.51.113	ELB-HealthChecker/1.0	1360167808	
fd64b7439eaf1147d83d8ec5ac637d61	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360167872	
89bd9544af4cc4ff3ede63b8a23b9a23	10.190.51.113	ELB-HealthChecker/1.0	1360163608	
57be8a150c42364f4a00b199683cc210	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360163671	
f13885ad7f19c90233a61e33fc4eaea9	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360163741	
b2cb3ad2c5279cf23bc35e42d9333ba0	10.190.51.113	ELB-HealthChecker/1.0	1360163819	
4fb8065df5e87800e2fcbd088095c9df	10.190.51.113	ELB-HealthChecker/1.0	1360163908	
da73ae3076ffe4f76e63a4c2566c1a7d	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360163971	
97b8416293fcac05e707a14249bbb1d6	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360164041	
b6293c9da52a74494c209d8377cf4e8d	10.190.51.113	ELB-HealthChecker/1.0	1360164118	
b5526724d8b684283e23348e1b0a6434	10.190.51.113	ELB-HealthChecker/1.0	1360164208	
f3d768c2052190d85d54bc86d4376485	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360164272	
206c0b1c0b00b101da482615c1d1f3a2	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360164341	
74f94d611bd37d77e6a272ef74c9ee0c	10.190.51.113	ELB-HealthChecker/1.0	1360164418	
e2a05318ed03c0b1bae4192643c6201f	10.190.51.113	ELB-HealthChecker/1.0	1360164508	
11ccaefaac1742d6f77d4c74de0aadfe	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360164573	
eda23e50df4448c176a2ae7e9c807c3c	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360164641	
b1c2b2e962fd92f63c974c28bde06c1a	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360166672	
741c4e315a7a8fa51e2fb4bb3fdc8aee	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360166742	
96c0a1a2c85cc684a82e8ed5993d88ed	10.190.51.113	ELB-HealthChecker/1.0	1360166818	
74bd0266ece447c04694c7173afed65a	10.190.51.113	ELB-HealthChecker/1.0	1360166908	
65d7428dd0aaf2da3487a80fa56563f2	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360166972	
6feded9c6b938b5a284170b8ed52b0cd	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360167041	
bf806a88bf7d8d7cd9d7262a83b18d5f	10.190.51.113	ELB-HealthChecker/1.0	1360167118	
35c61605399213a57ac4a002d6407230	94.254.4.85	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17	1360167208	a:3:{s:9:"user_data";s:0:"";s:9:"auth_user";s:1:"1";s:13:"auth_loggedin";b:1;}
ec6e9de8af9665b0ca4a1794ab2e4767	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360167273	
7634437140ed75ca07f4902666093a04	10.190.51.113	ELB-HealthChecker/1.0	1360167328	
039649a4cc0ab9d695490c3c8d2d5e4f	10.190.51.113	ELB-HealthChecker/1.0	1360167388	
1928d73a10b14cfe7ccb054bb7af795d	10.190.51.113	ELB-HealthChecker/1.0	1360167478	
2906d291f61df525badd4727431036bc	10.190.51.113	ELB-HealthChecker/1.0	1360167568	
f6d6b7c14e7f4d9e7a3ae347bde0d6eb	10.190.51.113	ELB-HealthChecker/1.0	1360167628	
5f1b00043d8a33b3c5b71fcdb36e7be3	10.190.51.113	ELB-HealthChecker/1.0	1360167688	
5d0ec252c8d446ef4eb4291f66927648	192.168.160.11	ELB-HealthChecker/1.0	1360167778	
e64c67d723a75fb82328482438a1d1b2	10.190.51.113	ELB-HealthChecker/1.0	1360167868	
b3c1dd6d0e6b3dcb48117d41a347b1bd	10.190.51.113	ELB-HealthChecker/1.0	1360163638	
032fb331c8bbd3b5721def1aba39fafe	10.190.51.113	ELB-HealthChecker/1.0	1360163705	
8475127b4c8e3f4753c984506329d675	10.190.51.113	ELB-HealthChecker/1.0	1360163758	
c3d9a0e5c94af8f0073694cb04af2811	10.190.51.113	ELB-HealthChecker/1.0	1360163848	
dbf2de8ca4b50ca636d9a1f994db06e0	10.190.51.113	ELB-HealthChecker/1.0	1360163938	
25bd2eb9e2b1a3d361b6183aa158ab48	10.190.51.113	ELB-HealthChecker/1.0	1360163998	
030e8da2222f1e92d27b29300831845c	10.190.51.113	ELB-HealthChecker/1.0	1360164058	
7a68bef14e1b9f12b25a7675aeb176a6	10.190.51.113	ELB-HealthChecker/1.0	1360164149	
3ce7a6e511e20d6941cc1cd02804b723	10.190.51.113	ELB-HealthChecker/1.0	1360164238	
48f2a1d8b27cf2b70b514c91c366aa41	10.190.51.113	ELB-HealthChecker/1.0	1360164298	
dfc6f519cc0bcf7aabed4e435a109a93	10.190.51.113	ELB-HealthChecker/1.0	1360164358	
9ff11796f5ea132df9e908fff840731e	10.190.51.113	ELB-HealthChecker/1.0	1360164448	
50948786ed2a4cfa3e04dbef9ac9e121	10.190.51.113	ELB-HealthChecker/1.0	1360164539	
77da8a0d226ac485d64a7442d2b56ecf	10.190.51.113	ELB-HealthChecker/1.0	1360164599	
ccec5059b12aad52ab68af5538ca23e3	10.190.51.113	ELB-HealthChecker/1.0	1360164658	
ef32dad3c9863dc330590eab3fa4f657	10.190.51.113	ELB-HealthChecker/1.0	1360166698	
6465279736509ba83cd8ace11e55429b	10.190.51.113	ELB-HealthChecker/1.0	1360166759	
4a4106ffe69ccac61b2da33bc615b332	10.190.51.113	ELB-HealthChecker/1.0	1360166848	
a226876bc4e4a211475f1343ac4f1993	10.190.51.113	ELB-HealthChecker/1.0	1360166938	
22578d9d10c4a2224c0d384e69a98fd9	10.190.51.113	ELB-HealthChecker/1.0	1360166998	
27db3d2d010333155a48d012df6d9852	10.190.51.113	ELB-HealthChecker/1.0	1360167058	
80cf0d6a710d862d5530f616b2b823e3	10.190.51.113	ELB-HealthChecker/1.0	1360167148	
964388f5d6eb8f4f8e30f8a5d25150e0	10.190.51.113	ELB-HealthChecker/1.0	1360167208	
c257a646a48da3896116959f3bbbf60c	10.190.51.113	ELB-HealthChecker/1.0	1360167268	
db9235d79bd32ed88812ba520028e285	192.168.1.131	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17	1360167317	a:3:{s:9:"user_data";s:0:"";s:9:"auth_user";s:1:"1";s:13:"auth_loggedin";b:1;}
b2546c1b680e72e5f1e260a7f83fcade	10.190.51.113	ELB-HealthChecker/1.0	1360167359	
f22bde842db7906acd86b6259b4013e9	10.190.51.113	ELB-HealthChecker/1.0	1360167448	
aed43fa2265108947be9527c404388ba	10.190.51.113	ELB-HealthChecker/1.0	1360167538	
d8759ab3763a511a710d92cbd4f0ba7b	10.190.51.113	ELB-HealthChecker/1.0	1360167598	
2fe265940c7272c5234ac04032079ddf	10.190.51.113	ELB-HealthChecker/1.0	1360167658	
6e7d4fe0f44b15b8b273d9e216400920	10.190.51.113	ELB-HealthChecker/1.0	1360167748	
5b0450c0e3c19d90bf941e1cfc74cc12	10.190.51.113	ELB-HealthChecker/1.0	1360167838	
897860a0c07e7a84819e77403e95fa4b	10.190.51.113	ELB-HealthChecker/1.0	1360167898	
692247cae1e8116afdc92640ba862ceb	10.190.51.113	ELB-HealthChecker/1.0	1360160608	
97c262f186a57e33c0e5074742e99444	10.190.51.113	ELB-HealthChecker/1.0	1360160638	
f60f2292bc012c601d30c672cbdd5bca	10.190.51.113	ELB-HealthChecker/1.0	1360160668	
ccde20b9a60c666ee9d3dd321cd0d6dd	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360160672	
22d1aed9d2f977f1cd02e9e6a86dfe1f	10.190.51.113	ELB-HealthChecker/1.0	1360160698	
52267a08bb05499dd6f5189f763a0af2	10.190.51.113	ELB-HealthChecker/1.0	1360160728	
b9ef5e2de0d297b527ae4051582b4a3b	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360160741	
32eaea609014f0c165174a4bbcb15d86	10.190.51.113	ELB-HealthChecker/1.0	1360160758	
259cb82cd18b1b26974fd5d03c96796d	10.190.51.113	ELB-HealthChecker/1.0	1360160788	
bf70dc3aa722c57b60aeb0cd64070632	10.190.51.113	ELB-HealthChecker/1.0	1360160818	
da62caaa8ae08109d410e2603089dd65	10.190.51.113	ELB-HealthChecker/1.0	1360160848	
34a45260ae16c1f5f2ee2a78ea8539f6	10.190.51.113	ELB-HealthChecker/1.0	1360160878	
7c6256c6b9aae8ec3becd4f6bb3624eb	10.190.51.113	ELB-HealthChecker/1.0	1360160908	
b83337b5526e671a5985d54e581af45a	10.190.51.113	ELB-HealthChecker/1.0	1360160938	
4b6268a0ad5f77d50209db0e833d65c0	10.190.51.113	ELB-HealthChecker/1.0	1360160968	
0ba8553d8159f95ceb4ef29e7339a713	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360160972	
a51077ef886fd75dc37c3b2e30260489	10.190.51.113	ELB-HealthChecker/1.0	1360160998	
01aa04ed4b3fc246f8aa08aaeddee125	10.190.51.113	ELB-HealthChecker/1.0	1360161028	
a55bfd896d022735e1906713bd843be6	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360161041	
8ac78f24f502b26333f2bf01f179b22b	10.190.51.113	ELB-HealthChecker/1.0	1360161058	
a065f45071cbdb5166354ae981c7f0f1	10.190.51.113	ELB-HealthChecker/1.0	1360161088	
f91ecf3c525af6741dadb11797fe20b6	10.190.51.113	ELB-HealthChecker/1.0	1360161118	
9ec0f4bf071e1e7ffae8c3b9b643473d	10.190.51.113	ELB-HealthChecker/1.0	1360161148	
340616a8a10f12ebccf4e9ef0d89fe87	10.190.51.113	ELB-HealthChecker/1.0	1360161178	
90a1710a89197cdb25a6aae69ad7cc8e	10.190.51.113	ELB-HealthChecker/1.0	1360161208	
881ea33c1e3f12ee162f73540ec08961	10.190.51.113	ELB-HealthChecker/1.0	1360161238	
dd75f7c274afc5d0dce3f66dedc26c56	10.190.51.113	ELB-HealthChecker/1.0	1360161268	
92947dbddaf88233f88a17d442a28454	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360161272	
983a4085a7f20c0be07bb3510c33955b	10.190.51.113	ELB-HealthChecker/1.0	1360161298	
c0750f9905d3a39a3de50960576afd2c	10.190.51.113	ELB-HealthChecker/1.0	1360161328	
295a0268195d9dfc828cb7b8459627a7	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360161341	
74a392aa7ce9a28a206f0a105bbddb54	10.190.51.113	ELB-HealthChecker/1.0	1360161358	
d11c50556220d748bedfa25642a26c03	10.190.51.113	ELB-HealthChecker/1.0	1360161388	
93a3fc9f3060fcf66f3581cfbbfc3bb6	10.190.51.113	ELB-HealthChecker/1.0	1360161418	
a402ca1538a946e9e9fdfd4cb0be1fa8	10.190.51.113	ELB-HealthChecker/1.0	1360161448	
9da0e7e718f561a9b3e3623e30ea4021	10.190.51.113	ELB-HealthChecker/1.0	1360161478	
0dbcc5248beaaea77eb30a6a90ebc1f8	10.190.51.113	ELB-HealthChecker/1.0	1360161508	
89c929150ad8bf61df8827ab0996088d	10.190.51.113	ELB-HealthChecker/1.0	1360161538	
95dcdbe82bbaff73a75be53ea9f717e4	10.190.51.113	ELB-HealthChecker/1.0	1360161568	
2b27c5724fc1a8cf8924995a5a9a94d6	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360161572	
1d17bd8c009379a8f541d1e161df638c	10.190.51.113	ELB-HealthChecker/1.0	1360161598	
45b8742e21c40c8cd0f477a1c7864c59	10.190.51.113	ELB-HealthChecker/1.0	1360161628	
7dd798c951db54ea166385a0d9f18903	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360161641	
bcf4f1be50be12ec4ad43d087e826806	10.190.51.113	ELB-HealthChecker/1.0	1360161658	
f5cc7041a417baac2d5493ae13112583	10.190.51.113	ELB-HealthChecker/1.0	1360161688	
2c99e238e0012a6f250329ff84cb6b59	10.190.51.113	ELB-HealthChecker/1.0	1360161778	
1f77840205cdc47e7ec78702cb62c4f5	10.190.51.113	ELB-HealthChecker/1.0	1360161868	
552cb9bc955885b6089ab8aa19aba41d	10.190.51.113	ELB-HealthChecker/1.0	1360161928	
296e64c963a0d5e23313cc22c9c2e5a9	10.190.51.113	ELB-HealthChecker/1.0	1360161988	
22b4e4d88611a3247e25e39751feedcb	10.190.51.113	ELB-HealthChecker/1.0	1360162078	
39b53786a5634ffd8f991c3897dea5f9	10.190.51.113	ELB-HealthChecker/1.0	1360162168	
fc2f61e4515ce298764c58b7aba62f76	10.190.51.113	ELB-HealthChecker/1.0	1360162228	
ecb8a04c03d5675d5a87a04954e8fe5b	10.190.51.113	ELB-HealthChecker/1.0	1360163668	
42b3ffd747dc9c1310c390900c65be2e	10.190.51.113	ELB-HealthChecker/1.0	1360163728	
0986555f40a06539620e1d11a32d1215	10.190.51.113	ELB-HealthChecker/1.0	1360163788	
f12c927275454683acc9d078ac9a5459	10.190.51.113	ELB-HealthChecker/1.0	1360163878	
5077995530f49c09c77f070f89cb34f2	10.190.51.113	ELB-HealthChecker/1.0	1360163968	
cba568843841355001322adad86fa1af	10.190.51.113	ELB-HealthChecker/1.0	1360164028	
d8fc00db622968ef054eb5bcca21dcaa	10.190.51.113	ELB-HealthChecker/1.0	1360164088	
9a953fe25f5ac5d6837b458d8a56e106	10.190.51.113	ELB-HealthChecker/1.0	1360164178	
da1977a7e6c7d34d3e44cba44b209d60	10.190.51.113	ELB-HealthChecker/1.0	1360164268	
b7eb27ac0862a7fd552501bb8c724299	10.190.51.113	ELB-HealthChecker/1.0	1360164328	
be750520faeadaf1259b0bcac7778f29	10.190.51.113	ELB-HealthChecker/1.0	1360164388	
7d96e5f0145ccf3130decbd0d97f29cc	10.190.51.113	ELB-HealthChecker/1.0	1360164478	
a838b81a192777ad67e4be2d3b06aa2b	10.190.51.113	ELB-HealthChecker/1.0	1360164568	
790781ab09067286f2b795e8b82025e6	10.190.51.113	ELB-HealthChecker/1.0	1360164628	
df2f9a365daf3ef98048263f91ea36b5	10.190.51.113	ELB-HealthChecker/1.0	1360161718	
132ce348300724dc8327be0afc92ca1a	10.190.51.113	ELB-HealthChecker/1.0	1360161808	
d63afa5d566ace7e372b9202f95fee06	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360161871	
94737890e263deec828309d29c9a46f0	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360161941	
f3f418afbf0e1a33f7c6a84d9787a2f3	10.190.51.113	ELB-HealthChecker/1.0	1360162018	
b6c1834adeb51bff6df6b0c5b6cfc97b	10.190.51.113	ELB-HealthChecker/1.0	1360162108	
c10f9d64f11c7b4f04d31c21f4d7b247	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360162171	
2fd18b962db10256ffd4a4a4acfdcbf8	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360162241	
56a513ec661df91363607b77458a6bd9	10.190.51.113	ELB-HealthChecker/1.0	1360164688	
3c33ae8677b2c3a1bf20b23c9fe80efb	10.190.51.113	ELB-HealthChecker/1.0	1360164778	
f85f6a6e01e4fae6547f4a8a7209e729	10.190.51.113	ELB-HealthChecker/1.0	1360164868	
0a2dbd57352f68679589279ee42db493	10.190.51.113	ELB-HealthChecker/1.0	1360164928	
518d482e582082c0a6d69d2c427eff5e	10.190.51.113	ELB-HealthChecker/1.0	1360164988	
5a35f9595d4a21e22b8d4c9191a37703	10.190.51.113	ELB-HealthChecker/1.0	1360165078	
53c0d1409a7c782c69202d7ec10fd933	10.190.51.113	ELB-HealthChecker/1.0	1360165169	
814704d0fb101c9f37aa85e5fc13afe7	10.190.51.113	ELB-HealthChecker/1.0	1360165228	
cf45686fbf05aedbeef2acf694df8388	10.190.51.113	ELB-HealthChecker/1.0	1360165288	
f061a28157e8138d27b621de9f5f65ae	10.190.51.113	ELB-HealthChecker/1.0	1360165378	
7bccb0a0702e24b30a4a8b77a081fab0	10.190.51.113	ELB-HealthChecker/1.0	1360165468	
8bc5b3aeb1b97475bf2bb5aaa2ebdea6	10.190.51.113	ELB-HealthChecker/1.0	1360165528	
69d8587c151d9330e86682952a077719	10.190.51.113	ELB-HealthChecker/1.0	1360165588	
f815c43802e152216db7120bf8743e85	10.190.51.113	ELB-HealthChecker/1.0	1360161748	
211e09c3f39a98f2205898983335e931	10.190.51.113	ELB-HealthChecker/1.0	1360161838	
e15590f554aa7b2c31b66a6768af5600	10.190.51.113	ELB-HealthChecker/1.0	1360161898	
8a4ebc4b17e65b226247ecc84e45e639	10.190.51.113	ELB-HealthChecker/1.0	1360161958	
28f8b2db6738749681c92e54d2465109	10.190.51.113	ELB-HealthChecker/1.0	1360162048	
cf86ae06d35a0add2d200373950b90eb	10.190.51.113	ELB-HealthChecker/1.0	1360162138	
389894f6e1f4ad627da04e184b0d6791	10.190.51.113	ELB-HealthChecker/1.0	1360162198	
132f74b543f9b4198e516b61dbd381ab	10.190.51.113	ELB-HealthChecker/1.0	1360162258	
074c35c2dfdab52bd493b40700f44ed0	10.190.51.113	ELB-HealthChecker/1.0	1360162288	
152a10e3317ae048f34cdbc94afa17ab	10.190.51.113	ELB-HealthChecker/1.0	1360162318	
6fa3d7a3cc342ea80ddac196612ba5fe	10.190.51.113	ELB-HealthChecker/1.0	1360164718	
e05d4da755992f7abc2b6e8572d8323e	10.190.51.113	ELB-HealthChecker/1.0	1360164809	
a0f8dc9f054486834bfbd60502ab0916	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360164872	
05ec17cd5ad3e765c81950bb7e62297d	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360164941	
787b66ce3aed97f888b453daf1c09d05	10.190.51.113	ELB-HealthChecker/1.0	1360165019	
4753294c2d366c5abfda5f86aa57318e	10.190.51.113	ELB-HealthChecker/1.0	1360165108	
14659c8f25da484ca29809e1e2f0a72b	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360165171	
79962bab82f4cc78a96ae64477141554	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360165241	
642d62ebbdaf038986f0577b22831869	10.190.51.113	ELB-HealthChecker/1.0	1360165318	
897903ffa53a2c8a2550b25aee43188b	10.190.51.113	ELB-HealthChecker/1.0	1360165408	
7ca00e752cc96b84579f03390b7c3727	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360165472	
c7b9241f01350edf85fa4cd2b1117bc1	192.168.160.1	check_http/v1.4.15 (nagios-plugins 1.4.15)	1360165541	
c98a1ec9d34105ac938a0860adda7240	10.190.51.113	ELB-HealthChecker/1.0	1360165618	
\.


--
-- Data for Name: keys; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY keys (id, key, level, ignore_limits, is_private_key, ip_addresses, date_created) FROM stdin;
1	b84b9eb779c6706ce75584c29b8005b1	2	f	f	\N	0
\.


--
-- Name: keys_id_seq; Type: SEQUENCE SET; Schema: klubb; Owner: klubb
--

SELECT pg_catalog.setval('keys_id_seq', 1, true);


--
-- Data for Name: limits; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY limits (id, uri, count, hour_started, api_key) FROM stdin;
\.


--
-- Name: limits_id_seq; Type: SEQUENCE SET; Schema: klubb; Owner: klubb
--

SELECT pg_catalog.setval('limits_id_seq', 1, false);


--
-- Data for Name: log; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY log (id, "user", action, path, "time") FROM stdin;
\.


--
-- Name: log_id_seq; Type: SEQUENCE SET; Schema: klubb; Owner: klubb
--

SELECT pg_catalog.setval('log_id_seq', 1, false);


--
-- Data for Name: logs; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY logs (id, uri, method, params, api_key, ip_address, "time", authorized) FROM stdin;
1	role/rights/role/2/X-API-KEY/b84b9eb779c6706ce75584c29b8005b1	get	a:2:{s:4:"role";s:1:"2";s:9:"X-API-KEY";s:32:"b84b9eb779c6706ce75584c29b8005b1";}	b84b9eb779c6706ce75584c29b8005b1	10.0.1.200	1357947309	f
2	role/rights/role/2/X-API-KEY/b84b9eb779c6706ce75584c29b8005b1	get	a:2:{s:4:"role";s:1:"2";s:9:"X-API-KEY";s:32:"b84b9eb779c6706ce75584c29b8005b1";}	b84b9eb779c6706ce75584c29b8005b1	10.0.1.200	1357947348	f
3	role/rights/role/2/X-API-KEY/b84b9eb779c6706ce75584c29b8005b1	get	a:2:{s:4:"role";s:1:"2";s:9:"X-API-KEY";s:32:"b84b9eb779c6706ce75584c29b8005b1";}	b84b9eb779c6706ce75584c29b8005b1	10.0.1.200	1357947449	f
4	role/rights/role/2/X-API-KEY/b84b9eb779c6706ce75584c29b8005b1	get	a:2:{s:4:"role";s:1:"2";s:9:"X-API-KEY";s:32:"b84b9eb779c6706ce75584c29b8005b1";}	b84b9eb779c6706ce75584c29b8005b1	10.0.1.200	1357947567	f
5	role/rights/role/2/X-API-KEY/b84b9eb779c6706ce75584c29b8005b1	get	a:2:{s:4:"role";s:1:"2";s:9:"X-API-KEY";s:32:"b84b9eb779c6706ce75584c29b8005b1";}	b84b9eb779c6706ce75584c29b8005b1	10.0.1.200	1357985995	f
6	role/rights/role/2/X-API-KEY/b84b9eb779c6706ce75584c29b8005b1	get	a:2:{s:4:"role";s:1:"2";s:9:"X-API-KEY";s:32:"b84b9eb779c6706ce75584c29b8005b1";}	b84b9eb779c6706ce75584c29b8005b1	10.0.1.200	1358034683	f
7	role/rights/role/2/X-API-KEY/b84b9eb779c6706ce75584c29b8005b1	get	a:2:{s:4:"role";s:1:"2";s:9:"X-API-KEY";s:32:"b84b9eb779c6706ce75584c29b8005b1";}	b84b9eb779c6706ce75584c29b8005b1	10.0.1.200	1358114101	f
8	role/rights/role/2/X-API-KEY/b84b9eb779c6706ce75584c29b8005b1	get	a:2:{s:4:"role";s:1:"2";s:9:"X-API-KEY";s:32:"b84b9eb779c6706ce75584c29b8005b1";}	b84b9eb779c6706ce75584c29b8005b1	10.0.1.200	1358114242	f
9	role/rights/role/2/X-API-KEY/b84b9eb779c6706ce75584c29b8005b1	get	a:2:{s:4:"role";s:1:"2";s:9:"X-API-KEY";s:32:"b84b9eb779c6706ce75584c29b8005b1";}	b84b9eb779c6706ce75584c29b8005b1	10.0.1.200	1358114258	f
10	role/rights/role/2	get	a:1:{s:4:"role";s:1:"2";}		10.0.1.200	1358114423	t
11	role/rights/role/2	get	a:1:{s:4:"role";s:1:"2";}		10.0.1.200	1358116197	t
12	role/rights/role/2	get	a:1:{s:4:"role";s:1:"2";}		10.0.1.200	1358118631	t
13	role/rights/role/2	get	a:1:{s:4:"role";s:1:"2";}		10.0.1.200	1358118734	t
14	role/rights/role/2	get	a:1:{s:4:"role";s:1:"2";}		94.254.4.85	1360153339	t
\.


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: klubb; Owner: klubb
--

SELECT pg_catalog.setval('logs_id_seq', 14, true);


--
-- Data for Name: member_data; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY member_data (id, notes, inactive, inactive_date) FROM stdin;
\.


--
-- Name: member_data_id_seq; Type: SEQUENCE SET; Schema: klubb; Owner: klubb
--

SELECT pg_catalog.setval('member_data_id_seq', 1, false);


--
-- Data for Name: members; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY members (id, type, firstname, lastname, ssid, phone, address, zip, city, data) FROM stdin;
\.


--
-- Name: members_id_seq; Type: SEQUENCE SET; Schema: klubb; Owner: klubb
--

SELECT pg_catalog.setval('members_id_seq', 1, false);


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY migrations (version) FROM stdin;
0
\.


--
-- Data for Name: rights; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY rights (id, role, add_members, add_users, use_system) FROM stdin;
1	1	t	f	t
2	2	f	f	t
3	3	t	t	t
\.


--
-- Name: rights_id_seq; Type: SEQUENCE SET; Schema: klubb; Owner: klubb
--

SELECT pg_catalog.setval('rights_id_seq', 3, true);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY roles (id, name, system) FROM stdin;
1	Administratör	t
2	Användare	t
3	Superadministratör	t
\.


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: klubb; Owner: klubb
--

SELECT pg_catalog.setval('roles_id_seq', 3, true);


--
-- Data for Name: system; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY system (key, value) FROM stdin;
org_name	Ung Cancer
app_name	Medlemsregistret
org_type	förening
inactive_title	Avliden
inactive_date_title	Datum
\.


--
-- Data for Name: types; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY types (id, name, plural, "desc") FROM stdin;
1	Medlem	Medlemmar	\N
2	Anhörigmedlem	Anhörigmedlemmar	\N
\.


--
-- Name: types_id_seq; Type: SEQUENCE SET; Schema: klubb; Owner: klubb
--

SELECT pg_catalog.setval('types_id_seq', 2, true);


--
-- Data for Name: user_role; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY user_role ("user", role) FROM stdin;
1	3
2	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: klubb; Owner: klubb
--

COPY users (id, username, firstname, lastname, email, phone, key, password, registered, first_login, loggedin) FROM stdin;
1	jan	Jan	Lindblom	jan@nyfagel.se	0731-509 338	w87p7zjWbikHvJ+yja0QqmCmWMb1GAjLNZjUYoMW/tiSKrK9iz+fpvwX4JFePKv3C1BTqE6U/2oR73RWAw7ljw==	$2a$08$gNc6oAbrTTT3tVeHTnE9je2oSUPvv7bxnzoE3qG9mks8EZZtgEHYG	1355861094	f	t
2	judith	Judith	Loménius	judith@ungcancer.se	\N	gLr0CLylw4x6+5z/zUcmSA9eSJqfgdBAYGE2zWglXtRuuaWBjAy/lJHA+maTWpkq9rcGlGZhCxuxsLMOxmXq8A==	$2a$08$yKhrHx8iSn6tpecXOdw1Zu/.rdOzgxJSkU3rHDGKGydtwma4BOW3y	1357119301	f	t
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: klubb; Owner: klubb
--

SELECT pg_catalog.setval('users_id_seq', 14, true);


--
-- Name: authentication_pkey; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY authentication
    ADD CONSTRAINT authentication_pkey PRIMARY KEY ("user", series);


--
-- Name: ci_sessions_pk; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY ci_sessions
    ADD CONSTRAINT ci_sessions_pk PRIMARY KEY (session_id);


--
-- Name: keys_key_key; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY keys
    ADD CONSTRAINT keys_key_key UNIQUE (key);


--
-- Name: keys_pkey; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY keys
    ADD CONSTRAINT keys_pkey PRIMARY KEY (id);


--
-- Name: limits_pkey; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY limits
    ADD CONSTRAINT limits_pkey PRIMARY KEY (id);


--
-- Name: log_pk; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY log
    ADD CONSTRAINT log_pk PRIMARY KEY (id);


--
-- Name: logs_pkey; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: member_data_pk; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY member_data
    ADD CONSTRAINT member_data_pk PRIMARY KEY (id);


--
-- Name: members_pkey; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: pk_id; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT pk_id PRIMARY KEY (id);


--
-- Name: rights_pkey; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY rights
    ADD CONSTRAINT rights_pkey PRIMARY KEY (id);


--
-- Name: roles_pkey; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: system_pkey; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY system
    ADD CONSTRAINT system_pkey PRIMARY KEY (key);


--
-- Name: types_pkey; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY types
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: u_email; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT u_email UNIQUE (email);


--
-- Name: u_username; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT u_username UNIQUE (username);


--
-- Name: user_role_pkey; Type: CONSTRAINT; Schema: klubb; Owner: klubb; Tablespace: 
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT user_role_pkey PRIMARY KEY ("user", role);


--
-- Name: fki_api_key_fk; Type: INDEX; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE INDEX fki_api_key_fk ON logs USING btree (api_key);


--
-- Name: fki_limits_api_key_fk; Type: INDEX; Schema: klubb; Owner: klubb; Tablespace: 
--

CREATE INDEX fki_limits_api_key_fk ON limits USING btree (api_key);


--
-- Name: members_data_fkey; Type: FK CONSTRAINT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY members
    ADD CONSTRAINT members_data_fkey FOREIGN KEY (data) REFERENCES member_data(id) ON DELETE SET NULL;


--
-- Name: members_type_fkey; Type: FK CONSTRAINT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY members
    ADD CONSTRAINT members_type_fkey FOREIGN KEY (type) REFERENCES types(id) ON DELETE SET NULL;


--
-- Name: user_fk; Type: FK CONSTRAINT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY authentication
    ADD CONSTRAINT user_fk FOREIGN KEY ("user") REFERENCES users(id) ON DELETE CASCADE;


--
-- Name: user_fk; Type: FK CONSTRAINT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY log
    ADD CONSTRAINT user_fk FOREIGN KEY ("user") REFERENCES users(id) ON DELETE SET NULL;


--
-- Name: user_role_role_fkey; Type: FK CONSTRAINT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT user_role_role_fkey FOREIGN KEY (role) REFERENCES roles(id) ON DELETE CASCADE;


--
-- Name: user_role_user_fkey; Type: FK CONSTRAINT; Schema: klubb; Owner: klubb
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT user_role_user_fkey FOREIGN KEY ("user") REFERENCES users(id) ON DELETE CASCADE;


--
-- Name: klubb; Type: ACL; Schema: -; Owner: klubb
--

REVOKE ALL ON SCHEMA klubb FROM PUBLIC;
REVOKE ALL ON SCHEMA klubb FROM klubb;
GRANT ALL ON SCHEMA klubb TO klubb;
GRANT ALL ON SCHEMA klubb TO PUBLIC;


--
-- PostgreSQL database dump complete
--

